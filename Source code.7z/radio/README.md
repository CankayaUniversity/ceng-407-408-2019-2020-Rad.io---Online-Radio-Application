#
```sudo service redis-server restart```
