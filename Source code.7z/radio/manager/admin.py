from django.contrib import admin
from .models import *

# admin.site.register(ModelName)

admin.site.register(Podcast)
admin.site.register(Event)
admin.site.register(LiveStream)
